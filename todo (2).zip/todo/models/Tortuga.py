import pygame
import random
import os  # Asegurar importación de módulo os

class Tortuga(pygame.sprite.Sprite):
    def __init__(self, juego):
        super().__init__()
        self.juego = juego
        self.image = pygame.transform.scale(
            pygame.image.load(os.path.join("pictures", "tortuga.png")).convert_alpha(),  # Ruta corregida
            (50, 50)
        )
        self.rect = self.image.get_rect()
        self.resetear_posicion()
        self.velocidad = random.choice([-8, 8])  # Aumentar velocidad
        self.vel_y = -5  # Ajustar para mejor trayectoria
        self.gravedad = 0.5

    def resetear_posicion(self):
        # Posiciones iniciales más cercanas
        lado = random.choice(["izquierda", "derecha"])
        if lado == "izquierda":
            self.rect.x = -50  # Acercar al borde
            self.velocidad = 4  # Mayor velocidad
        else:
            self.rect.x = self.juego.SCREEN_WIDTH + 50
            self.velocidad = -4
        
        self.rect.y = random.randint(100, 300)  # Altura inicial ajustada
        self.vel_y = -4  # Impulso vertical inicial

    def update(self):
        # Movimiento parabólico mejorado
        self.rect.x += self.velocidad
        self.rect.y += self.vel_y
        self.vel_y += self.gravedad
        
        # Reiniciar solo al salir por los laterales
        if (self.rect.right < 0 and self.velocidad < 0) or \
           (self.rect.left > self.juego.SCREEN_WIDTH and self.velocidad > 0):
            self.resetear_posicion()