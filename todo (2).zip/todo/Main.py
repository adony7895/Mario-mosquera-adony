import pygame
import os

from models.Enemigo import Enemigo
from models.Estrella import Estrella
from models.Hongo import Hongo
from models.Jugador import Jugador
from models.Moneda import Moneda
from models.Tortuga import Tortuga

class Main:
    def __init__(self):
        pygame.init()

        # Configuración general
        self.SCREEN_WIDTH = 800
        self.SCREEN_HEIGHT = 600
        self.LIMITE_INFERIOR_Y = 515
        self.FPS = 60
        self.COLORES = {"blanco": (255, 255, 255), "negro": (0, 0, 0)}

        self.pantalla = pygame.display.set_mode((self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
        pygame.display.set_caption("Mario Adventure")

        # Cargar recursos
        self.cargar_sonidos()
        self.fondo = pygame.transform.scale(
            self.cargar_imagen("fondo.jpeg"), (self.SCREEN_WIDTH, self.SCREEN_HEIGHT)
        )
        self.fuente = pygame.font.Font(None, 36)

        # Grupos de sprites
        self.todos_sprites = pygame.sprite.Group()
        self.monedas = pygame.sprite.Group()
        self.enemigos = pygame.sprite.Group()
        self.powerups = pygame.sprite.Group()

        # Variables de estado
        self.Moneda_contador = 0
        self.ejecutando = True
        self.pausado = False
        self.reloj = pygame.time.Clock()

        # Inicializar elementos del juego
        self.inicializar_elementos()

        # Temporizadores para generación de enemigos
        self.tiempo_ultimo_goomba_cafe = 0
        self.tiempo_ultimo_goomba_negro = 0
        self.tiempo_ultima_tortuga = 0
        self.intervalo_cafe = 4000
        self.intervalo_negro = 7000
        self.intervalo_tortuga = 10000

    def cargar_imagen(self, nombre):
        return pygame.image.load(os.path.join("pictures", nombre)).convert_alpha()

    def cargar_sonidos(self):
        self.sonidos = {
            'moneda': pygame.mixer.Sound('sounds/coin.wav'),
            'daño': pygame.mixer.Sound('sounds/damage.wav'),
            'salto': pygame.mixer.Sound('sounds/jump.wav'),
            'powerup': pygame.mixer.Sound('sounds/powerup.wav'),
            'enemigo': pygame.mixer.Sound('sounds/enemy_hit.wav')
        }

    def inicializar_elementos(self):
        # Jugador
        self.jugador = Jugador(self)
        self.todos_sprites.add(self.jugador)

        # Monedas
        for _ in range(10):
            moneda = Moneda(self)
            self.monedas.add(moneda)
            self.todos_sprites.add(moneda)

        # Powerups
        self.hongo_crecimiento = Hongo(
            self, "crecimiento", 100, self.LIMITE_INFERIOR_Y - 50
        )
        self.hongo_vida = Hongo(self, "vida", 700, self.LIMITE_INFERIOR_Y - 50)
        self.estrella = Estrella(self, 400, self.LIMITE_INFERIOR_Y - 50)
        self.powerups.add(self.hongo_crecimiento)
        self.powerups.add(self.hongo_vida)
        self.powerups.add(self.estrella)
        self.todos_sprites.add(self.hongo_crecimiento)
        self.todos_sprites.add(self.hongo_vida)
        self.todos_sprites.add(self.estrella)

    def iniciar(self):
        # Pantalla inicial
        esperando = True
        while esperando:
            self.pantalla.fill(self.COLORES["negro"])
            texto = self.fuente.render(
                "Presiona ENTER para iniciar", True, self.COLORES["blanco"]
            )
            self.pantalla.blit(
                texto,
                (
                    self.SCREEN_WIDTH // 2 - texto.get_width() // 2,
                    self.SCREEN_HEIGHT // 2,
                ),
            )
            pygame.display.flip()

            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    self.salir()
                if evento.type == pygame.KEYDOWN and evento.key == pygame.K_RETURN:
                    esperando = False

    def manejar_colisiones(self):
        # Colisiones con monedas
        for moneda in pygame.sprite.spritecollide(self.jugador, self.monedas, True):
            self.Moneda_contador += 1
            self.sonidos['moneda'].play()
            moneda.resetear_posicion()
            self.monedas.add(moneda)
            self.todos_sprites.add(moneda)

            if self.Moneda_contador >= 10:
                self.jugador.vidas += 1
                self.Moneda_contador = 0
                self.sonidos['powerup'].play()

        # Colisiones con powerups
        for powerup in pygame.sprite.spritecollide(self.jugador, self.powerups, False):
            if powerup.visible:
                if isinstance(powerup, Hongo):
                    powerup.recolectar()
                    self.sonidos['powerup'].play()
                    if powerup.tipo == "crecimiento":
                        self.jugador.estado = "grande"
                        self.jugador.actualizar_tamano()
                    else:
                        self.jugador.vidas += 1
                elif isinstance(powerup, Estrella):
                    self.jugador.estado = "inmune"
                    self.jugador.tiempo_inmunidad = pygame.time.get_ticks() + powerup.duracion
                    powerup.recolectar()
                    self.sonidos['powerup'].play()

        # Colisiones con enemigos
        if self.jugador.vidas > 0:
            for enemigo in pygame.sprite.spritecollide(self.jugador, self.enemigos, False):
                # Detectar si el jugador salta sobre el enemigo
                if self.jugador.vel_y > 0 and self.jugador.rect.bottom < enemigo.rect.centery:
                    enemigo.kill()
                    self.jugador.vel_y = -10
                    self.sonidos['enemigo'].play()
                elif self.jugador.estado != "inmune":
                    if self.jugador.estado == "grande":
                        self.jugador.estado = "pequeño"
                        self.jugador.actualizar_tamano()
                        enemigo.kill()
                        self.sonidos['daño'].play()
                    else:
                        self.jugador.vidas -= 1
                        self.sonidos['daño'].play()
                        if self.jugador.vidas <= 0:
                            self.game_over()
                            return
                        else:
                            self.jugador.rect.topleft = (100, self.LIMITE_INFERIOR_Y - 50)

    def actualizar_enemigos(self, tiempo_actual):
        # Generar enemigos continuamente sin límite de cantidad
        if tiempo_actual - self.tiempo_ultimo_goomba_cafe > self.intervalo_cafe:
            enemigo = Enemigo(self, "cafe")
            self.enemigos.add(enemigo)
            self.todos_sprites.add(enemigo)
            self.tiempo_ultimo_goomba_cafe = tiempo_actual
            print("Goomba café creado")

        if tiempo_actual - self.tiempo_ultimo_goomba_negro > self.intervalo_negro:
            enemigo = Enemigo(self, "negro")
            self.enemigos.add(enemigo)
            self.todos_sprites.add(enemigo)
            self.tiempo_ultimo_goomba_negro = tiempo_actual
            print("Goomba negro creado")

        if tiempo_actual - self.tiempo_ultima_tortuga > self.intervalo_tortuga:
            tortuga = Tortuga(self)
            self.enemigos.add(tortuga)
            self.todos_sprites.add(tortuga)
            self.tiempo_ultima_tortuga = tiempo_actual
            print("Tortuga creada")

    def manejar_reaparicion_objetos(self, tiempo_actual):
        # Reaparición de hongos
        for hongo in [self.hongo_crecimiento, self.hongo_vida]:
            if not hongo.visible and tiempo_actual > hongo.tiempo_reaparicion:
                hongo.aparecer()

        # Reaparición de estrella
        if not self.estrella.visible and tiempo_actual > self.estrella.tiempo_reaparicion:
            self.estrella.aparecer()

    def manejar_eventos(self):
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                self.salir()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_p:  # Pausa con tecla P
                    self.pausado = not self.pausado
                if evento.key == pygame.K_r and not self.ejecutando:
                    self.resetear_juego()

    def game_over(self):
        # Pantalla de game over
        self.ejecutando = False 
        game_over = True
        while game_over:
            self.pantalla.fill(self.COLORES["negro"])
            texto1 = self.fuente.render("GAME OVER", True, (255, 0, 0))
            texto2 = self.fuente.render(
                "Presiona R para reiniciar o ESC para salir",
                True,
                self.COLORES["blanco"],
            )
            self.pantalla.blit(
                texto1,
                (
                    self.SCREEN_WIDTH // 2 - texto1.get_width() // 2,
                    self.SCREEN_HEIGHT // 2 - 50,
                ),
            )
            self.pantalla.blit(
                texto2,
                (
                    self.SCREEN_WIDTH // 2 - texto2.get_width() // 2,
                    self.SCREEN_HEIGHT // 2 + 10,
                ),
            )
            pygame.display.flip()

            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    self.salir()
                if evento.type == pygame.KEYDOWN:
                    if evento.key == pygame.K_r:
                        self.resetear_juego()
                        game_over = False
                    if evento.key == pygame.K_ESCAPE:
                        self.salir()

    def resetear_juego(self):
        # Reiniciar estado
        self.Moneda_contador = 0
        self.ejecutando = True
        self.pausado = False
        self.jugador.vidas = 3
        self.jugador.estado = "pequeño"
        self.jugador.actualizar_tamano()
        self.jugador.rect.topleft = (100, self.LIMITE_INFERIOR_Y - 50)

        # Limpiar enemigos
        for enemigo in self.enemigos:
            enemigo.kill()

        # Reubicar monedas
        for moneda in self.monedas:
            moneda.resetear_posicion()
            self.todos_sprites.add(moneda)

        # Reaparecer powerups
        for powerup in self.powerups:
            powerup.aparecer()

    def mostrar_hud(self):
        # Vidas
        vidas_texto = self.fuente.render(f"Vidas: {self.jugador.vidas}", True, self.COLORES["blanco"])
        self.pantalla.blit(vidas_texto, (10, 10))

        # Monedas
        monedas_texto = self.fuente.render(f"Monedas: {self.Moneda_contador}", True, self.COLORES["blanco"])
        self.pantalla.blit(monedas_texto, (10, 40))

        # Tiempo inmunidad
        if self.jugador.estado == "inmune":
            tiempo_restante = max(0, (self.jugador.tiempo_inmunidad - pygame.time.get_ticks()) // 1000)
            inmunidad_texto = self.fuente.render(f"Inmune: {tiempo_restante}s", True, (255, 215, 0))
            self.pantalla.blit(inmunidad_texto, (self.SCREEN_WIDTH - 150, 10))

    def bucle_principal(self):
        self.iniciar()

        while self.ejecutando:
            self.manejar_eventos()

            if not self.pausado:
                tiempo_actual = pygame.time.get_ticks()

                self.manejar_colisiones()
                self.actualizar_enemigos(tiempo_actual)
                self.manejar_reaparicion_objetos(tiempo_actual)

                # Actualizar sprites
                self.todos_sprites.update()

                # Dibujar todo
                self.pantalla.blit(self.fondo, (0, 0))
                self.todos_sprites.draw(self.pantalla)
                self.mostrar_hud()

                pygame.display.flip()

            self.reloj.tick(self.FPS)

    def salir(self):
        pygame.quit()
        exit()

juego = Main()
juego.iniciar()
juego.bucle_principal()  