
# Super Adony Bros - Juego de Plataformas con Pygame

Super Adony Bros es un juego de plataformas 2D inspirado en el clásico Super Mario Bros. Este proyecto está desarrollado en Python utilizando la biblioteca Pygame.

## 🎮 Características

- Control de jugador con salto y movimiento lateral
- Enemigos con colisiones
- Power-ups: Hongos para crecer, estrellas para invulnerabilidad
- Sistema de vidas
- Monedas recolectables
- Estados del jugador: pequeño, grande, inmune
- Inmunidad temporal luego de recibir daño
- Diseño modular basado en clases

## 🛠 Estructura del Proyecto

```
Main.py                   # Punto de entrada del juego
models/Jugador.py         # Clase Jugador
models/Enemigo.py         # Clase Enemigo
models/Moneda.py          # Clase Moneda
models/Hongo.py           # Power-up Hongo
models/Estrella.py        # Power-up Estrella
models/Tortuga.py         # Enemigo
pictures/                 # Imágenes
sounds/                   # Sonidos
README.md                 # Este archivo
```

## 📦 Requisitos

- Python 3.8 o superior
- Pygame

Instalación de Pygame:

```bash
pip install pygame
```

## ▶️ Cómo jugar

1. Clona este repositorio:

```bash
git clone https://github.com/adony7895/Mario-mosquera-adony
cd Mario-mosquera-adony
```

2. Ejecuta el juego:

```bash
python main.py
```

## ⌨️ Controles

- **Flechas**: Moverse
- **Espacio**: Saltar

## 📸 Captura
![](pictures/preview.png)

---

Desarrollado con ❤️ por Adony Gabriel Perea Cuero.