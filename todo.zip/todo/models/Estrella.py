import pygame
import random

class Estrella(pygame.sprite.Sprite):
        def __init__(self, juego, x, y):
            super().__init__()
            self.juego = juego
            self.image = pygame.transform.scale(juego.cargar_imagen("estrella.png"), (40, 40))
            self.rect = self.image.get_rect(topleft=(x, y))
            self.duracion = 8000
            self.visible = True
            self.tiempo_reaparicion = 0
            
        def aparecer(self):
            self.visible = True
            self.rect.topleft = (random.randint(50, self.juego.SCREEN_WIDTH-50), 
                                random.randint(self.juego.LIMITE_INFERIOR_Y-150, self.juego.LIMITE_INFERIOR_Y-50))
            self.juego.powerups.add(self)
            self.juego.todos_sprites.add(self)
            self.tiempo_reaparicion = pygame.time.get_ticks() + 10000
            
        def recolectar(self):
            self.visible = False
            self.tiempo_reaparicion = pygame.time.get_ticks() + 10000
            self.juego.powerups.remove(self)
            self.juego.todos_sprites.remove(self)