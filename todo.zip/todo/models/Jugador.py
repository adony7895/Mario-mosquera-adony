import pygame


class Jugador(pygame.sprite.Sprite):
    def __init__(self, juego):
        super().__init__()
        self.estado = "pequeño"
        self.juego = juego
        self.imagen_original = juego.cargar_imagen("player.png")
        self.imagen_salto = juego.cargar_imagen("player_salto.png")
        self.image = pygame.transform.scale(
            self.imagen_original, self.obtener_tamano_actual()
        )
        self.rect = self.image.get_rect(topleft=(100, juego.LIMITE_INFERIOR_Y - 50))

        self.vidas = 3
        self.tiempo_inmunidad = 0
        self.velocidad = 5
        self.vel_y = 0
        self.en_suelo = True
        self.salto_potencia = -15
        self.gravedad = 1

    def obtener_tamano_actual(self):
        return (60, 60) if self.estado == "grande" else (50, 50)

    def actualizar_imagen(self, imagen, voltear=False):
        imagen_escalada = pygame.transform.scale(imagen, self.obtener_tamano_actual())
        if voltear:
            imagen_escalada = pygame.transform.flip(imagen_escalada, True, False)
        self.image = imagen_escalada
        # Actualizar el rectángulo para que coincida con la nueva imagen
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))

    def actualizar_tamano(self):
        self.actualizar_imagen(self.imagen_original)

    def update(self):
        teclas = pygame.key.get_pressed()
        dx = 0

        if teclas[pygame.K_LEFT]:
            dx -= self.velocidad
            self.actualizar_imagen(self.imagen_original, voltear=True)

        elif teclas[pygame.K_RIGHT]:
            dx += self.velocidad
            self.actualizar_imagen(self.imagen_original)

        self.mover_horizontalmente(dx)

        # Saltar
        if teclas[pygame.K_SPACE] and self.en_suelo:
            self.vel_y = self.salto_potencia
            self.en_suelo = False
            self.actualizar_imagen(self.imagen_salto)

        self.aplicar_gravedad()
        self.verificar_colision_suelo()
        self.verificar_inmunidad()

    def mover_horizontalmente(self, dx):
        nueva_x = self.rect.x + dx
        nueva_x = max(0, min(nueva_x, self.juego.SCREEN_WIDTH - self.rect.width))
        self.rect.x = nueva_x

    def aplicar_gravedad(self):
        self.vel_y += self.gravedad
        self.rect.y += self.vel_y

    def verificar_colision_suelo(self):
        if self.rect.bottom >= self.juego.LIMITE_INFERIOR_Y:
            self.rect.bottom = self.juego.LIMITE_INFERIOR_Y
            self.vel_y = 0
            if not self.en_suelo:
                self.en_suelo = True
                self.actualizar_imagen(self.imagen_original)

    def verificar_inmunidad(self):
        if self.estado == "inmune" and pygame.time.get_ticks() > self.tiempo_inmunidad:
            self.estado = "grande" if self.image.get_size()[0] == 60 else "pequeño"
            self.actualizar_tamano()
