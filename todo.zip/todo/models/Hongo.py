import pygame
import random

class Hongo(pygame.sprite.Sprite):
        def __init__(self, juego, tipo, x, y):
            super().__init__()
            self.juego = juego
            self.tipo = tipo
            self.image = pygame.transform.scale(juego.cargar_imagen("hongo.png" if tipo == "crecimiento" else "vida.png"), (40, 40))
            self.rect = self.image.get_rect(topleft=(x, y))
            self.visible = False
            self.tiempo_reaparicion = 0
            
        def aparecer(self):
            self.visible = True
            self.rect.topleft = (random.randint(50, self.juego.SCREEN_WIDTH-50), 
                                random.randint(self.juego.LIMITE_INFERIOR_Y-150, self.juego.LIMITE_INFERIOR_Y-50))
            self.juego.powerups.add(self)
            self.juego.todos_sprites.add(self)
            
        def recolectar(self):
            self.visible = False
            self.tiempo_reaparicion = pygame.time.get_ticks() + 5000
            self.juego.powerups.remove(self)
            self.juego.todos_sprites.remove(self)
