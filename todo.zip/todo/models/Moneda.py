import pygame
import random

class Moneda(pygame.sprite.Sprite):
        def __init__(self, juego):
            super().__init__()
            self.juego = juego
            self.image = pygame.transform.scale(juego.cargar_imagen("coin.png"), (30, 30))
            self.rect = self.image.get_rect()
            self.resetear_posicion()

        def resetear_posicion(self):
            self.rect.x = random.randint(0, self.juego.SCREEN_WIDTH - 30)
            self.rect.y = random.randint(self.juego.LIMITE_INFERIOR_Y - 150, self.juego.LIMITE_INFERIOR_Y - 30)
