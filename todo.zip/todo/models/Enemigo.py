import pygame

class Enemigo(pygame.sprite.Sprite):
        def __init__(self, juego, tipo):
            super().__init__()
            self.juego = juego
            self.tipo = tipo
            self.image = pygame.transform.scale(juego.cargar_imagen(f"goomba_{tipo}.png"), (40, 40))
            self.rect = self.image.get_rect(topleft=(juego.SCREEN_WIDTH, juego.LIMITE_INFERIOR_Y - 45))
            self.velocidad = 3 if tipo == "cafe" else 5

        def update(self):
            self.rect.x -= self.velocidad
            if self.rect.right < 0:
                self.kill()